<?php

namespace BlueSpice;

interface IPageHeaderBeforeContent {
}
