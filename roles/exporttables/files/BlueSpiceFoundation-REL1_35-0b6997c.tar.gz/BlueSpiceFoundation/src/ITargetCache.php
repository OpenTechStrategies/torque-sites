<?php

namespace BlueSpice;

interface ITargetCache {

	/**
	 * @return string
	 */
	public function getRegistryKey();

}
