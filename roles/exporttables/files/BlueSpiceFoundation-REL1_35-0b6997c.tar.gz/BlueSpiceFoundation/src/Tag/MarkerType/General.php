<?php

namespace BlueSpice\Tag\MarkerType;

use BlueSpice\Tag\MarkerType;

class General extends MarkerType {
	public function __toString() {
		return 'general';
	}
}
