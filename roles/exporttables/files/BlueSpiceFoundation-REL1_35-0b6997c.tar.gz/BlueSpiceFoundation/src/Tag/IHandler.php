<?php

namespace BlueSpice\Tag;

interface IHandler {

	/**
	 * @return string
	 */
	public function handle();
}
