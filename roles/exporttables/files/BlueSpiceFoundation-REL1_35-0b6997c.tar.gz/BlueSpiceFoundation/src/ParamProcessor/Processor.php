<?php

namespace BlueSpice\ParamProcessor;

class Processor extends \ParamProcessor\Processor {
}
