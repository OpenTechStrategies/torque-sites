<?php

namespace BlueSpice\ParamProcessor;

class Options extends \ParamProcessor\Options {
}
