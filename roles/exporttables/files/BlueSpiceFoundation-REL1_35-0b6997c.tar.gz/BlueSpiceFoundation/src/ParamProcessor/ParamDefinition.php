<?php

namespace BlueSpice\ParamProcessor;

use ParamProcessor\ParamDefinition as BaseClass;

class ParamDefinition extends BaseClass implements IParamDefinition {
}
