<?php

namespace BlueSpice\ParamProcessor;

use ParamProcessor\IParamDefinition as BaseInterface;

interface IParamDefinition extends BaseInterface {

}
