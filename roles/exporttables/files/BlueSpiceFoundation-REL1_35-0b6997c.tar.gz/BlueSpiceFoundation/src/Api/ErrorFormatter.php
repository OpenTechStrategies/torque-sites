<?php

namespace BlueSpice\Api;

use ApiErrorFormatter;

class ErrorFormatter extends ApiErrorFormatter {
}
