<?php

namespace BlueSpice\TargetCache;

interface ITarget {

	/**
	 * @return string
	 */
	public function getIdentifier();
}
