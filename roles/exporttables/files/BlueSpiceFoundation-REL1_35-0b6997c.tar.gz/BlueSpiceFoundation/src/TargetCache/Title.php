<?php

namespace BlueSpice\TargetCache;

class Title extends \BlueSpice\TargetCache {

	/**
	 *
	 * @return string
	 */
	public function getRegistryKey() {
		return 'BlueSpiceFoundationTargetCacheTitleRegistry';
	}

}
