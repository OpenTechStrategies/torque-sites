<?php

namespace BlueSpice\Renderer;

class NullRenderer extends \BlueSpice\Renderer {
	public function render() {
		return '';
	}
}
