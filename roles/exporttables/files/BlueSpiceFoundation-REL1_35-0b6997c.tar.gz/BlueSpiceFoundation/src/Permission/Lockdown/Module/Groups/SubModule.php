<?php

namespace BlueSpice\Permission\Lockdown\Module\Groups;

abstract class SubModule extends \BlueSpice\Permission\Lockdown\Module implements ISubModule {
}
