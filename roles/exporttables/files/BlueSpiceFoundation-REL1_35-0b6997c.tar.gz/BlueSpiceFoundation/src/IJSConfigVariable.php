<?php

namespace BlueSpice;

interface IJSConfigVariable {

	/**
	 * Get the value of the variable
	 *
	 * @return mixed
	 */
	public function getValue();
}
