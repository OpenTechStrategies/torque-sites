<?php

namespace BlueSpice\ConfigDefinition;

interface IOverwriteGlobal {
	/**
	 * @return string
	 */
	public function getGlobalName();
}
