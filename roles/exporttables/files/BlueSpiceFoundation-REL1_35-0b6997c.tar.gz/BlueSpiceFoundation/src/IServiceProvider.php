<?php

namespace BlueSpice;

interface IServiceProvider {
	/**
	 * @return Services
	 */
	public function getServices();
}
