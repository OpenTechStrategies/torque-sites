<?php

namespace BlueSpice\Data\Settings;

class Record extends \BlueSpice\Data\Record {
	const NAME = 's_name';
	const VALUE = 's_value';
}
