<?php

namespace BlueSpice\Data\User;

class Record extends \BlueSpice\Data\Record {
	const ID = 'user_id';
	const USER_NAME = 'user_name';
	const USER_REAL_NAME = 'user_real_name';
}
