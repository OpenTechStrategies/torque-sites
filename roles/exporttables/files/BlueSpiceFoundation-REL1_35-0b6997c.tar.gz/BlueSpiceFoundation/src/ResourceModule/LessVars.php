<?php

namespace BlueSpice\ResourceModule;

use MWStake\MediaWiki\Component\CommonUserInterface\ResourceLoader\LessVars as LessVarsLib;

/**
 * @deprecated Since 3.3 Use MWStake\MediaWiki\Component\CommonUserInterface\ResourceLoader\LessVars instead
 */
class LessVars extends LessVarsLib {
}
