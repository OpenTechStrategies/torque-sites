<?php

namespace BlueSpice;

interface IRenderer {
	/**
	 * @return string
	 */
	public function render();
}
