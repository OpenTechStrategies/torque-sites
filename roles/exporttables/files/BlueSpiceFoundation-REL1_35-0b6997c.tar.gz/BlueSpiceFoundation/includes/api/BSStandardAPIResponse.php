<?php

/**
 * DEPRECATED
 * This response should implement the ExtJS standard format for serverside
 * form validations:
 * http://docs.sencha.com/extjs/4.2.2/#!/api/Ext.form.action.Submit
 *
 * TODO: do a clean implemenation with gettes and setters
 * @deprecated since version 3.1 - Use \BlueSpice\Api\Response\Standard instead
 */
class BSStandardAPIResponse extends \BlueSpice\Api\Response\Standard {
}
