<?php
$specialPageAliases = [];

/** English */
$specialPageAliases['en'] = [
	'UniversalExport' => [ 'UniversalExport', 'Universal Export' ],
];

/** German (Deutsch) */
$specialPageAliases['de'] = [
	'UniversalExport' => [ 'Universal Export' ],
];

/** German (Deutsch) */
$specialPageAliases['de-formal'] = [
	'UniversalExport' => [ 'Universal Export' ],
];
