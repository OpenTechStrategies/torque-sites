( function ( mw, $, d, undefined ) {
	var basePath = mw.config.get( "wgExtensionAssetsPath" );
	Ext.Loader.setPath(	'MWExt', basePath + '/ExtJSBase/resources/MWExt' );
})( mediaWiki, jQuery, document );