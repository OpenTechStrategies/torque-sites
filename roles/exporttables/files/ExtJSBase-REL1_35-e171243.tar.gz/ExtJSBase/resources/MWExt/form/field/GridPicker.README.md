# General
This 'GridPicker' implementation is based upon the work of 'rixo' [1] and
'yogeshpandey009' [2]. It has been modified to be compatible to ExtJS version 6.

[1] https://github.com/rixo/GridPicker
[2] https://github.com/yogeshpandey009/GridPicker-4.2.2

# Files
* `GridPicker.js`
* `GridPickerKeyNav.js`