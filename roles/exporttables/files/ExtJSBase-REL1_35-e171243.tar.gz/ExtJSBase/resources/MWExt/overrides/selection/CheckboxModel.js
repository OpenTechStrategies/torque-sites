Ext.override( Ext.selection.CheckboxModel, {
	headerWidth: 32
});