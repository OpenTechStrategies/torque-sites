Ext.override( Ext.grid.plugin.RowExpander, {
	columnWidth: 32,
	headerWidth:32
});