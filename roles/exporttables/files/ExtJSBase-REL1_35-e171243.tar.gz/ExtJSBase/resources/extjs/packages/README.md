Packages come from the official ExtJS 6.2 build. Just like `ext-all.js` they are
"classic toolkit". The CSS files are build against the "Crisp" default theme.
There are no adaptions for cutom `theme-mediawiki-touch` theme.