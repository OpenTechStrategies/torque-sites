Third Party Licenses
====================
This is an overview of all the 3rd party licenses used in this module.

Images
------

| Image | Author | Version | License |
|:--------|:-------|:--------|:-------|
| [Famfamfam Silk Icon set 1.3](http://www.famfamfam.com/lab/icons/silk/) | Mark James | 1.3 | [CC-BY 3.0](https://creativecommons.org/licenses/by/3.0/) |

License texts
=============
All licenses can be found in full text in the folder

```BlueSpiceFoundation/doc/legal```

or online at

https://github.com/wikimedia/mediawiki-extensions-BlueSpiceFoundation/tree/master/doc/legal